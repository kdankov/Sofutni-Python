from project.animal import Animal


class Dog(Animal):
    def sound(self):
        return 'Woof!'

