from project.animal import Animal


class Cat(Animal):
    def sound(self):
        return 'Meow meow!'
